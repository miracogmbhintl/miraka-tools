const e="/".replace(/\/$/,"");export{e as b};
