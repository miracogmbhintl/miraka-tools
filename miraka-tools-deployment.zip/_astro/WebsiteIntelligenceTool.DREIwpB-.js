import{j as e}from"./jsx-runtime.D_zvdyIk.js";import{r as c}from"./index.CRdpAhVf.js";import{b as A}from"./base-url.DVjYrgnb.js";/* empty css                          */import{c as d}from"./createLucideIcon.CB-2PyP6.js";/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]],C=d("circle-alert",z);/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],B=d("circle-check",D);/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]],M=d("file-text",I);/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],k=d("loader-circle",$);/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]],V=d("message-square",O);function U(){const[p,v]=c.useState(""),[m,h]=c.useState("idle"),[t,u]=c.useState(null),[w,b]=c.useState(""),[f,x]=c.useState([{label:"Retrieving public website data",status:"pending"},{label:"Interpreting business structure",status:"pending"},{label:"Identifying positioning signals",status:"pending"},{label:"Generating intelligence variables",status:"pending"}]),y=async()=>{if(!p.trim())return;h("analyzing"),b(""),u(null),[500,1500,2500,3500].forEach((s,a)=>{setTimeout(()=>{x(l=>l.map((n,g)=>g<a?{...n,status:"complete"}:g===a?{...n,status:"active"}:n))},s)});try{const s=await fetch(`${A}/api/analyze-website`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:p.trim()})}),a=await s.json();if(!s.ok)throw new Error(a.error||"Analysis failed");x(l=>l.map(n=>({...n,status:"complete"}))),u(a.data),h("complete")}catch(s){console.error("Analysis error:",s),b(s instanceof Error?s.message:"Failed to analyze website"),h("error"),x(f.map(a=>({...a,status:"pending"})))}},j=()=>{v(""),h("idle"),u(null),b(""),x(f.map(i=>({...i,status:"pending"})))},S=()=>{if(!t)return;const i=[];i.push(`
      <tr>
        <td colspan="2" style="font-weight: bold; padding-top: 12px; font-size: 11px;">EXECUTIVE SNAPSHOT</td>
      </tr>
      <tr><td>Business Type</td><td>${t.executiveSnapshot.businessType}</td></tr>
      <tr><td>Market Scope</td><td>${t.executiveSnapshot.marketScope}</td></tr>
      <tr><td>Primary Goal</td><td>${t.executiveSnapshot.primaryGoal}</td></tr>
      <tr><td>Clarity Score</td><td>${t.executiveSnapshot.clarityScore}/100</td></tr>
    `),i.push(`
      <tr>
        <td colspan="2" style="font-weight: bold; padding-top: 12px; font-size: 11px;">CORE VARIABLES</td>
      </tr>
      <tr><td>Business Type</td><td>${t.coreVariables.businessType}</td></tr>
      <tr><td>Target Audience</td><td>${t.coreVariables.targetAudience}</td></tr>
      <tr><td>Offer Structure</td><td>${t.coreVariables.offerStructure}</td></tr>
      ${t.coreVariables.pricingNote?`<tr><td>Pricing Note</td><td>${t.coreVariables.pricingNote}</td></tr>`:""}
      <tr><td>Pricing Positioning</td><td>${t.coreVariables.pricingPositioning}</td></tr>
      <tr><td>Conversion Focus</td><td>${t.coreVariables.conversionFocus}</td></tr>
      <tr><td>Content Depth</td><td>${t.coreVariables.contentDepth}</td></tr>
      <tr><td>Trust Signals</td><td>${t.coreVariables.trustSignals}</td></tr>
      <tr><td>Structural Weaknesses</td><td>${t.coreVariables.structuralWeaknesses}</td></tr>
    `),i.push(`
      <tr>
        <td colspan="2" style="font-weight: bold; padding-top: 12px; font-size: 11px;">STRATEGIC SIGNALS</td>
      </tr>
    `),t.strategicSignals.forEach((o,E)=>{i.push(`<tr><td>${E+1}</td><td>${o}</td></tr>`)}),i.push(`
      <tr>
        <td colspan="2" style="font-weight: bold; padding-top: 12px; font-size: 11px;">NEXT MOVES</td>
      </tr>
    `),t.nextMoves.forEach(o=>{i.push(`
        <tr>
          <td style="vertical-align: top;">${o.title} <span style="font-size: 9px; text-transform: uppercase; color: #666;">[${o.priority}]</span></td>
          <td>${o.description}</td>
        </tr>
      `)});const s=`
      <table>
        <thead>
          <tr>
            <th style="width: 35%;">Variable</th>
            <th style="width: 65%;">Value</th>
          </tr>
        </thead>
        <tbody>
          ${i.join("")}
        </tbody>
      </table>
    `,a=new Date,l=a.getFullYear(),n=a.toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"}),g=`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Business Data Export – Miraka & Co</title>

  <style>
  
    /* ===============================
       PAGE SETUP – A4 SYMMETRIC
       =============================== */
    @page {
      size: A4;
      margin: 25mm 20mm 25mm 20mm; /* TOP | RIGHT | BOTTOM | LEFT */
    }

    body {
      margin: 0;
      padding: 0;
      font-family: Helvetica, Arial, sans-serif;
      font-size: 11px;
      color: #111;
      line-height: 1.5;
    }

    /* ===============================
       HEADER
       =============================== */
    header {
      width: 100%;
      text-align: center;
      margin-bottom: 30px;
    }

    header img {
      width: 4cm;
      max-width: 4cm;
      height: auto;
      display: block;
      margin: 0 auto 12px auto;
    }

    header h1 {
      font-size: 14px;
      font-weight: normal;
      margin: 0;
      letter-spacing: 0.5px;
    }

    /* ===============================
       TABLE CONTENT
       =============================== */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      page-break-inside: auto;
    }

    thead {
      display: table-header-group;
    }

    tr {
      page-break-inside: avoid;
      page-break-after: auto;
    }

    th {
      text-align: left;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.4px;
      border-bottom: 1px solid #000;
      padding: 6px 4px;
    }

    td {
      border-bottom: 1px solid #e5e5e5;
      padding: 6px 4px;
      vertical-align: top;
    }

    /* ===============================
       FOOTER – SYMMETRIC POSITION
       =============================== */
    footer {
      position: fixed;
      bottom: 12.5mm; /* exact center of bottom margin */
      left: 20mm;
      right: 20mm;
      font-size: 8.5px;
      color: #666;
      line-height: 1.4;
    }

    .footer-block {
      margin-top: 6px;
    }

    .footer-title {
      font-weight: bold;
      color: #333;
      margin-bottom: 2px;
    }
  </style>
</head>

<body>

  <!-- ===============================
       HEADER
       =============================== -->
  <header>
    <img
      src="https://cdn.prod.website-files.com/68dc2b9c31cb83ac9f84a1af/68e0480bc44f1d28032afb51_LOGO%20MIRAKA%20%26%20CO%20PLAIN%20TEXT.png"
      alt="Miraka & Co"
    />
    <h1>Business Data Overview</h1>
  </header>

  <!-- ===============================
       DYNAMIC CONTENT
       =============================== -->
  ${s}

  <!-- ===============================
       FOOTER
       =============================== -->
  <footer>

    <div class="footer-block">
      <div class="footer-title">Company Information</div>
      Miraka & Co GmbH<br />
      Elisabethenstrasse 41, CH-4051 Basel, Switzerland<br />
      www.miraka.ch · office@miraka.ch
    </div>

    <div class="footer-block">
      <div class="footer-title">Data Source & Information Disclaimer</div>
      This document contains business-related information retrieved from publicly available sources at the time of generation. Miraka & Co GmbH does not guarantee accuracy, completeness, or continued availability of the data.
    </div>

    <div class="footer-block">
      <div class="footer-title">Non-Solicitation & Usage Restriction Clause</div>
      The information in this document must not be used for unsolicited communication, advertising, or direct marketing. Usage must comply with GDPR / DSGVO and Swiss data protection law.
    </div>

    <div class="footer-block">
      <div class="footer-title">Data Protection & GDPR / DSGVO Compliance</div>
      This document does not constitute a database or lead list. No personal data is intentionally processed. Responsibility for lawful handling lies with the recipient.
    </div>

    <div class="footer-block">
      <div class="footer-title">Limitation of Liability</div>
      Miraka & Co GmbH shall not be liable for any damages arising from use or interpretation of this document.
    </div>

    <div class="footer-block">
      © ${l} Miraka & Co GmbH · Generated on ${n}
    </div>

  </footer>

</body>
</html>`,T=new Blob([g],{type:"text/html"}),N=URL.createObjectURL(T),r=document.createElement("a");r.href=N,r.download=`website-intelligence-${new Date().toISOString().split("T")[0]}.html`,document.body.appendChild(r),r.click(),document.body.removeChild(r),URL.revokeObjectURL(N)},F=()=>{window.open("https://miraka.ch/contact","_blank")};return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`
        .intel-container {
          font-family: 'Inter Tight', sans-serif;
          position: relative;
          min-height: 100vh;
          width: 100vw;
          padding: 20px;
          box-sizing: border-box;
        }
        
        .intel-back-button {
          position: fixed;
          left: calc((40px + 24px) / 2);
          top: 50%;
          transform: translate(-50%, -50%);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          text-decoration: none;
          z-index: 1000;
          transition: all 0.2s ease;
        }
        
        .intel-logo {
          display: none;
        }
        
        .intel-content {
          max-width: 1200px;
          margin: 0 auto;
          padding-left: 40px;
        }
        
        .intel-card {
          background: #FFFFFF;
          border-radius: 14px;
          padding: 24px;
          border: 1px solid #E5E7EB;
          box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
          margin-bottom: 16px;
        }
        
        .intel-header {
          margin-bottom: 24px;
        }
        
        .intel-title {
          font-family: 'Inter Tight', sans-serif;
          font-size: 2rem;
          font-weight: 700;
          letter-spacing: -0.02em;
          color: #1A1A1A;
          margin: 0 0 8px 0;
        }
        
        .intel-subtitle {
          font-family: 'Inter Tight', sans-serif;
          font-size: 15px;
          color: #6B7280;
          margin: 0;
          line-height: 1.5;
        }
        
        .intel-input {
          width: 100%;
          height: 48px;
          padding: 0 16px;
          border: 1px solid #E5E7EB;
          border-radius: 12px;
          fontSize: 15px;
          fontFamily: 'Inter Tight', sans-serif;
          color: #1A1A1A;
          background: #FFFFFF;
          transition: all 0.2s ease;
          outline: none;
          margin-bottom: 12px;
        }
        
        .intel-input:focus {
          border-color: #1A1A1A;
          box-shadow: 0 0 0 3px rgba(26, 26, 26, 0.05);
        }
        
        .intel-button {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          height: 44px;
          padding: 0 24px;
          font-size: 14px;
          font-weight: 600;
          font-family: 'Inter Tight', sans-serif;
          color: #FFFFFF;
          background: #1A1A1A;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          width: 100%;
        }
        
        .intel-button:hover:not(:disabled) {
          background: #2A2A2A;
          transform: translateY(-1px);
        }
        
        .intel-button:disabled {
          background: #E5E7EB;
          color: #9CA3AF;
          cursor: not-allowed;
          transform: none;
        }
        
        .intel-button-group {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
        }
        
        @media (max-width: 768px) {
          .intel-button-group {
            grid-template-columns: 1fr;
          }
        }
        
        .intel-spinner {
          animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        .intel-progress-header {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
          margin-bottom: 24px;
        }
        
        .intel-progress-header h3 {
          font-family: 'Inter Tight', sans-serif;
          font-size: 18px;
          font-weight: 600;
          color: #1A1A1A;
          margin: 0;
        }
        
        .intel-steps {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        
        .intel-step {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px 16px;
          background: #F9FAFB;
          border-radius: 0 10px 10px 0;
          transition: all 0.3s ease;
        }
        
        .intel-step.active {
          background: #FEF3E7;
          border-left: 5px solid #F37021;
        }
        
        .intel-step.complete {
          background: #F0FDF4;
          border-left: 5px solid #10B981;
        }
        
        .intel-step-icon {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 20px;
          height: 20px;
          color: #9CA3AF;
        }
        
        .intel-step.active .intel-step-icon {
          color: #F37021;
        }
        
        .intel-step.complete .intel-step-icon {
          color: #10B981;
        }
        
        .intel-step-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #D1D5DB;
        }
        
        .intel-step span {
          font-family: 'Inter Tight', sans-serif;
          font-size: 14px;
          color: #4B5563;
          font-weight: 500;
        }
        
        .intel-step.active span,
        .intel-step.complete span {
          color: #1A1A1A;
        }
        
        .intel-error-state {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 16px;
          padding: 48px 24px;
          text-align: center;
        }
        
        .intel-error-state h3 {
          font-family: 'Inter Tight', sans-serif;
          font-size: 18px;
          font-weight: 600;
          color: #1A1A1A;
          margin: 0;
        }
        
        .intel-error-state p {
          font-family: 'Inter Tight', sans-serif;
          font-size: 14px;
          color: #6B7280;
          max-width: 400px;
          margin: 0;
        }
        
        .intel-section-title {
          font-family: 'Inter Tight', sans-serif;
          font-size: 16px;
          font-weight: 700;
          color: #1A1A1A;
          margin: 0 0 16px 0;
          letter-spacing: -0.01em;
        }
        
        .intel-snapshot-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
        }
        
        .intel-snapshot-item {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        
        .intel-snapshot-label {
          font-size: 12px;
          color: #6B7280;
          font-weight: 500;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }
        
        .intel-snapshot-value {
          font-size: 15px;
          color: #1A1A1A;
          font-weight: 600;
        }
        
        .intel-variables-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        
        .intel-variable-item {
          display: flex;
          flex-direction: column;
          gap: 4px;
          padding: 12px;
          background: #F9FAFB;
          border-radius: 8px;
        }
        
        .intel-variable-label {
          font-size: 12px;
          color: #6B7280;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }
        
        .intel-variable-value {
          font-size: 14px;
          color: #1A1A1A;
          line-height: 1.5;
        }
        
        .intel-signals-list {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        
        .intel-signal-item {
          padding: 12px 16px;
          padding-left: 16px;
          background: #F9FAFB;
          border-left: 5px solid #1A1A1A;
          border-radius: 0 8px 8px 0;
          font-size: 14px;
          color: #1A1A1A;
          line-height: 1.5;
        }
        
        .intel-moves-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        
        .intel-move-item {
          padding: 16px;
          background: #F9FAFB;
          border-radius: 10px;
        }
        
        .intel-move-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 8px;
        }
        
        .intel-move-title {
          font-size: 15px;
          font-weight: 600;
          color: #1A1A1A;
          margin: 0;
        }
        
        .intel-move-priority {
          font-size: 11px;
          font-weight: 700;
          padding: 4px 8px;
          border-radius: 6px;
          letter-spacing: 0.05em;
        }
        
        .intel-move-priority.high {
          background: #FEE2E2;
          color: #991B1B;
        }
        
        .intel-move-priority.medium {
          background: #FEF3C7;
          color: #92400E;
        }
        
        .intel-move-priority.low {
          background: #DBEAFE;
          color: #1E3A8A;
        }
        
        .intel-move-description {
          font-size: 14px;
          color: #4B5563;
          line-height: 1.5;
          margin: 0;
        }
        
        @media (max-width: 768px) {
          .intel-container {
            padding: 12px;
          }
          
          .intel-back-button {
            position: fixed;
            left: 12px;
            top: 12px;
            transform: none;
          }
          
          .intel-logo {
            display: block;
            position: fixed;
            right: 12px;
            top: 12px;
            z-index: 1000;
          }
          
          .intel-content {
            padding-left: 0;
            padding-top: 50px;
          }
          
          .intel-snapshot-grid {
            grid-template-columns: 1fr;
          }
        }
      `}),e.jsxs("div",{className:"intel-container",children:[e.jsx("a",{href:`${A}/`,className:"intel-back-button",onMouseEnter:i=>{const s=i.currentTarget.querySelector("svg");s&&s.setAttribute("stroke","#F37021")},onMouseLeave:i=>{const s=i.currentTarget.querySelector("svg");s&&s.setAttribute("stroke","#1A1A1A")},children:e.jsx("svg",{width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"#1A1A1A",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",children:e.jsx("path",{d:"M15 18l-6-6 6-6"})})}),e.jsx("div",{className:"intel-logo",children:e.jsx("img",{src:"https://cdn.prod.website-files.com/68dc2b9c31cb83ac9f84a1af/68e0480bc44f1d28032afb51_LOGO%20MIRAKA%20%26%20CO%20PLAIN%20TEXT.png",alt:"Miraka & Co.",style:{height:"18px",width:"auto",display:"block"}})}),e.jsxs("div",{className:"intel-content",children:[e.jsxs("div",{className:"intel-header",children:[e.jsx("h1",{className:"intel-title",children:"Website Intelligence"}),e.jsx("p",{className:"intel-subtitle",children:"Instant clarity on business structure, positioning, and strategic opportunities."})]}),m==="idle"&&e.jsxs("div",{className:"intel-card",children:[e.jsx("input",{type:"url",value:p,onChange:i=>v(i.target.value),onKeyDown:i=>i.key==="Enter"&&y(),placeholder:"Enter website URL (e.g., https://example.com)",className:"intel-input"}),e.jsx("button",{onClick:y,className:"intel-button",disabled:!p.trim(),children:"Analyze Website"})]}),m==="analyzing"&&e.jsxs("div",{className:"intel-card",children:[e.jsxs("div",{className:"intel-progress-header",children:[e.jsx(k,{size:24,className:"intel-spinner"}),e.jsx("h3",{children:"Analyzing website..."})]}),e.jsx("div",{className:"intel-steps",children:f.map((i,s)=>e.jsxs("div",{className:`intel-step ${i.status}`,children:[e.jsxs("div",{className:"intel-step-icon",children:[i.status==="complete"&&e.jsx(B,{size:20}),i.status==="active"&&e.jsx(k,{size:20,className:"intel-spinner"}),i.status==="pending"&&e.jsx("div",{className:"intel-step-dot"})]}),e.jsx("span",{children:i.label})]},s))})]}),m==="error"&&e.jsx("div",{className:"intel-card",children:e.jsxs("div",{className:"intel-error-state",children:[e.jsx(C,{size:48,color:"#D5455F"}),e.jsx("h3",{children:"Analysis Failed"}),e.jsx("p",{children:w}),e.jsx("button",{onClick:j,className:"intel-button",children:"Try Again"})]})}),m==="complete"&&t&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"intel-card",children:[e.jsx("h2",{className:"intel-section-title",children:"Executive Snapshot"}),e.jsxs("div",{className:"intel-snapshot-grid",children:[e.jsxs("div",{className:"intel-snapshot-item",children:[e.jsx("span",{className:"intel-snapshot-label",children:"Business Type"}),e.jsx("span",{className:"intel-snapshot-value",children:t.executiveSnapshot.businessType})]}),e.jsxs("div",{className:"intel-snapshot-item",children:[e.jsx("span",{className:"intel-snapshot-label",children:"Market Scope"}),e.jsx("span",{className:"intel-snapshot-value",children:t.executiveSnapshot.marketScope})]}),e.jsxs("div",{className:"intel-snapshot-item",children:[e.jsx("span",{className:"intel-snapshot-label",children:"Primary Goal"}),e.jsx("span",{className:"intel-snapshot-value",children:t.executiveSnapshot.primaryGoal})]}),e.jsxs("div",{className:"intel-snapshot-item",children:[e.jsx("span",{className:"intel-snapshot-label",children:"Clarity Score"}),e.jsxs("span",{className:"intel-snapshot-value",children:[t.executiveSnapshot.clarityScore,"/100"]})]})]})]}),e.jsxs("div",{className:"intel-card",children:[e.jsx("h2",{className:"intel-section-title",children:"Core Variables"}),e.jsxs("div",{className:"intel-variables-list",children:[e.jsxs("div",{className:"intel-variable-item",children:[e.jsx("span",{className:"intel-variable-label",children:"Business Type"}),e.jsx("span",{className:"intel-variable-value",children:t.coreVariables.businessType})]}),e.jsxs("div",{className:"intel-variable-item",children:[e.jsx("span",{className:"intel-variable-label",children:"Target Audience"}),e.jsx("span",{className:"intel-variable-value",children:t.coreVariables.targetAudience})]}),e.jsxs("div",{className:"intel-variable-item",children:[e.jsx("span",{className:"intel-variable-label",children:"Offer Structure"}),e.jsx("span",{className:"intel-variable-value",children:t.coreVariables.offerStructure})]}),t.coreVariables.pricingNote&&e.jsxs("div",{className:"intel-variable-item",children:[e.jsx("span",{className:"intel-variable-label",children:"Pricing Note"}),e.jsx("span",{className:"intel-variable-value",children:t.coreVariables.pricingNote})]}),e.jsxs("div",{className:"intel-variable-item",children:[e.jsx("span",{className:"intel-variable-label",children:"Pricing Positioning"}),e.jsx("span",{className:"intel-variable-value",children:t.coreVariables.pricingPositioning})]}),e.jsxs("div",{className:"intel-variable-item",children:[e.jsx("span",{className:"intel-variable-label",children:"Conversion Focus"}),e.jsx("span",{className:"intel-variable-value",children:t.coreVariables.conversionFocus})]}),e.jsxs("div",{className:"intel-variable-item",children:[e.jsx("span",{className:"intel-variable-label",children:"Content Depth"}),e.jsx("span",{className:"intel-variable-value",children:t.coreVariables.contentDepth})]}),e.jsxs("div",{className:"intel-variable-item",children:[e.jsx("span",{className:"intel-variable-label",children:"Trust Signals"}),e.jsx("span",{className:"intel-variable-value",children:t.coreVariables.trustSignals})]}),e.jsxs("div",{className:"intel-variable-item",children:[e.jsx("span",{className:"intel-variable-label",children:"Structural Weaknesses"}),e.jsx("span",{className:"intel-variable-value",children:t.coreVariables.structuralWeaknesses})]})]})]}),e.jsxs("div",{className:"intel-card",children:[e.jsx("h2",{className:"intel-section-title",children:"Strategic Signals"}),e.jsx("div",{className:"intel-signals-list",children:t.strategicSignals.map((i,s)=>e.jsx("div",{className:"intel-signal-item",children:i},s))})]}),e.jsxs("div",{className:"intel-card",children:[e.jsx("h2",{className:"intel-section-title",children:"Next Moves"}),e.jsx("div",{className:"intel-moves-list",children:t.nextMoves.map((i,s)=>e.jsxs("div",{className:"intel-move-item",children:[e.jsxs("div",{className:"intel-move-header",children:[e.jsx("h4",{className:"intel-move-title",children:i.title}),e.jsx("span",{className:`intel-move-priority ${i.priority}`,children:i.priority.toUpperCase()})]}),e.jsx("p",{className:"intel-move-description",children:i.description})]},s))})]}),e.jsx("div",{className:"intel-card",children:e.jsxs("div",{className:"intel-button-group",children:[e.jsxs("button",{onClick:S,className:"intel-button",children:[e.jsx(M,{size:18,strokeWidth:2}),"Download PDF"]}),e.jsxs("button",{onClick:F,className:"intel-button",children:[e.jsx(V,{size:18,strokeWidth:2}),"Request Review"]}),e.jsx("button",{onClick:j,className:"intel-button",children:"Analyze Another"})]})})]})]})]})]})}export{U as default};
