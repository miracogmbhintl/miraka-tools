globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate } from '../chunks/astro/server_CnmPaQ2a.mjs';
import { $ as $$Main } from '../chunks/main_DK0-QX4D.mjs';
export { renderers } from '../renderers.mjs';

const $$Tools = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, {}, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "ToolsShell", null, { "client:only": "react", "title": "Tools", "currentPath": "/tools", "client:component-hydration": "only", "client:component-path": "/app/src/components/ToolsShell", "client:component-export": "default" }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "ToolsPage", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/ToolsPage", "client:component-export": "default" })} ` })} ` })}`;
}, "/app/src/pages/tools.astro", void 0);

const $$file = "/app/src/pages/tools.astro";
const $$url = "/tools";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Tools,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
