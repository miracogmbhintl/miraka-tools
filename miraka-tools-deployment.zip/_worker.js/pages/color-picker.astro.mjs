globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate } from '../chunks/astro/server_CnmPaQ2a.mjs';
import { $ as $$Main } from '../chunks/main_DK0-QX4D.mjs';
export { renderers } from '../renderers.mjs';

const $$ColorPicker = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, {}, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "ToolsShell", null, { "client:only": "react", "title": "Color Picker", "currentPath": "/color-picker", "client:component-hydration": "only", "client:component-path": "/app/src/components/ToolsShell", "client:component-export": "default" }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "ColorPickerTool", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/ColorPickerTool", "client:component-export": "default" })} ` })} ` })}`;
}, "/app/src/pages/color-picker.astro", void 0);

const $$file = "/app/src/pages/color-picker.astro";
const $$url = "/color-picker";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$ColorPicker,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
