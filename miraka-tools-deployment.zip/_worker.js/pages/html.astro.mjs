globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, o as renderHead, k as renderComponent, r as renderTemplate } from '../chunks/astro/server_CnmPaQ2a.mjs';
/* empty css                                */
export { renderers } from '../renderers.mjs';

const $$Html = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`<html lang="en" data-astro-cid-26sziipj> <head><meta charset="utf-8"><link rel="icon" type="image/png" href="/favicon.ico"><meta name="viewport" content="width=device-width"><title>HTML Preview Tool - Miraka Tools</title>${renderHead()}</head> <body data-astro-cid-26sziipj> ${renderComponent($$result, "HTMLPreviewTool", null, { "client:only": "react", "client:component-hydration": "only", "data-astro-cid-26sziipj": true, "client:component-path": "/app/src/components/HTMLPreviewTool", "client:component-export": "default" })} </body></html>`;
}, "/app/src/pages/html.astro", void 0);

const $$file = "/app/src/pages/html.astro";
const $$url = "/html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Html,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
