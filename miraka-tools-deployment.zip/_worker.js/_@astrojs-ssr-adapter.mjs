globalThis.process ??= {}; globalThis.process.env ??= {};
export { c as createExports } from './chunks/_@astrojs-ssr-adapter_D4sEqKWK.mjs';
