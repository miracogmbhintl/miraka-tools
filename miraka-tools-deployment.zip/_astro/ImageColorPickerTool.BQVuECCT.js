import{j as e}from"./jsx-runtime.D_zvdyIk.js";import{r as p}from"./index.CRdpAhVf.js";import{b as U}from"./base-url.DVjYrgnb.js";import{c as M}from"./createLucideIcon.CB-2PyP6.js";import{C as G,a as Y}from"./copy.DYW1hB-b.js";/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _=[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]],O=M("upload",_);/**
 * @license lucide-react v0.533.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],J=M("x",q);function te(){const[b,A]=p.useState(null),[x,w]=p.useState("#F37021"),[y,E]=p.useState(null),[C,I]=p.useState({x:0,y:0}),[v,m]=p.useState(null),j=p.useRef(null),k=p.useRef(null),R=t=>{const n=t.target.files?.[0];if(n&&n.type.startsWith("image/")){const l=new FileReader;l.onload=o=>{const i=o.target?.result;A(i),setTimeout(()=>{const r=new Image;r.onload=()=>{const a=j.current;if(a){const d=a.getContext("2d");if(d){let s=r.width,c=r.height;s>800&&(c=c*800/s,s=800),c>600&&(s=s*600/c,c=600),a.width=s,a.height=c,d.drawImage(r,0,0,s,c)}}},r.src=i},100)},l.readAsDataURL(n)}},F=t=>{const n=j.current;if(!n)return"#000000";const l=n.getContext("2d");if(!l)return"#000000";const o=n.getBoundingClientRect(),i=n.width/o.width,r=n.height/o.height;let a,d;"touches"in t?(a=t.touches[0].clientX,d=t.touches[0].clientY):(a=t.clientX,d=t.clientY);const u=(a-o.left)*i,f=(d-o.top)*r,s=l.getImageData(u,f,1,1),[c,X,N]=s.data;return L(c,X,N)},T=t=>{const n=F(t);w(n)},B=t=>{t.preventDefault();const n=F(t);w(n),m(n)},z=t=>{I({x:t.clientX,y:t.clientY});const n=F(t);m(n)},W=()=>{m(null)},L=(t,n,l)=>"#"+[t,n,l].map(o=>{const i=Math.max(0,Math.min(255,o)).toString(16);return i.length===1?"0"+i:i}).join(""),S=t=>{const n=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(t);return n?{r:parseInt(n[1],16),g:parseInt(n[2],16),b:parseInt(n[3],16)}:{r:0,g:0,b:0}},H=t=>{const n=S(t),l=n.r/255,o=n.g/255,i=n.b/255,r=Math.max(l,o,i),a=Math.min(l,o,i);let d=0,u=0;const f=(r+a)/2;if(r!==a){const s=r-a;switch(u=f>.5?s/(2-r-a):s/(r+a),r){case l:d=((o-i)/s+(o<i?6:0))/6;break;case o:d=((i-l)/s+2)/6;break;case i:d=((l-o)/s+4)/6;break}}return{h:Math.round(d*360),s:Math.round(u*100),l:Math.round(f*100)}},g=S(x),h=H(x),D=(t,n)=>{navigator.clipboard.writeText(t),E(n),setTimeout(()=>E(null),2e3)},P=[{label:"HEX",value:x.toUpperCase()},{label:"RGB",value:`rgb(${g.r}, ${g.g}, ${g.b})`},{label:"HSL",value:`hsl(${h.h}, ${h.s}%, ${h.l}%)`}],$=()=>{A(null),m(null),k.current&&(k.current.value="")};return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`
        .image-picker-container {
          font-family: Inter, sans-serif;
          position: relative;
          width: 100vw;
          height: 100vh;
          padding: 20px;
          box-sizing: border-box;
          overflow: hidden;
        }
        
        .image-picker-back-button {
          position: fixed;
          left: calc((40px + 24px) / 2);
          top: 50%;
          transform: translate(-50%, -50%);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          text-decoration: none;
          z-index: 1000;
          transition: all 0.2s ease;
        }
        
        .image-picker-logo {
          display: none;
        }
        
        .image-picker-grid {
          display: grid;
          grid-template-columns: ${b?"1fr 400px":"1fr"};
          gap: 24px;
          height: 100%;
          padding-left: 40px;
        }
        
        @media (max-width: 768px) {
          .image-picker-container {
            padding: 12px;
            height: auto;
            min-height: 100vh;
            overflow-y: auto;
          }
          
          .image-picker-back-button {
            position: fixed;
            left: 12px;
            top: 12px;
            transform: none;
          }
          
          .image-picker-logo {
            display: block;
            position: fixed;
            right: 12px;
            top: 12px;
            z-index: 1000;
            font-family: 'Montserrat', sans-serif;
            font-size: 16px;
            font-weight: 700;
            color: #1A1A1A;
          }
          
          .image-picker-grid {
            display: flex;
            flex-direction: column;
            gap: 16px;
            padding-left: 0;
            padding-top: 50px;
          }
        }
      `}),e.jsxs("div",{className:"image-picker-container",children:[e.jsx("a",{href:`${U}/`,className:"image-picker-back-button",onMouseEnter:t=>{const n=t.currentTarget.querySelector("svg");n&&n.setAttribute("stroke","#F37021")},onMouseLeave:t=>{const n=t.currentTarget.querySelector("svg");n&&n.setAttribute("stroke","#1A1A1A")},children:e.jsx("svg",{width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"#1A1A1A",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",children:e.jsx("path",{d:"M15 18l-6-6 6-6"})})}),e.jsx("div",{className:"image-picker-logo",children:e.jsx("img",{src:"https://cdn.prod.website-files.com/68dc2b9c31cb83ac9f84a1af/68e0480bc44f1d28032afb51_LOGO%20MIRAKA%20%26%20CO%20PLAIN%20TEXT.png",alt:"Miraka & Co.",style:{height:"18px",width:"auto",display:"block"}})}),e.jsxs("div",{className:"image-picker-grid",children:[e.jsx("div",{style:{display:"flex",flexDirection:"column",gap:"16px",height:"100%",overflow:"hidden"},children:e.jsxs("div",{style:{background:"#FFFFFF",borderRadius:"14px",padding:"24px",border:"1px solid #E5E7EB",boxShadow:"0 1px 2px rgba(0, 0, 0, 0.04)",display:"flex",flexDirection:"column",height:"100%",overflow:"hidden"},children:[e.jsx("div",{style:{display:"flex",alignItems:"center",justifyContent:"flex-end",marginBottom:"16px"},children:e.jsx("div",{style:{display:"flex",gap:"8px"},children:b&&e.jsx(e.Fragment,{children:e.jsx("button",{onClick:$,style:{display:"flex",alignItems:"center",justifyContent:"center",width:"36px",height:"36px",background:"#EF4444",color:"#FFFFFF",border:"none",borderRadius:"8px",cursor:"pointer",transition:"all 0.2s ease"},onMouseEnter:t=>{t.currentTarget.style.background="#DC2626"},onMouseLeave:t=>{t.currentTarget.style.background="#EF4444"},children:e.jsx(J,{size:16,strokeWidth:2})})})})}),e.jsx("div",{style:{flex:1,display:"flex",alignItems:"center",justifyContent:"center",borderRadius:"12px",border:"2px dashed #E5E7EB",background:"#FAFAFA",position:"relative",overflow:"hidden"},children:b?e.jsxs("div",{style:{position:"relative",display:"flex",alignItems:"center",justifyContent:"center",width:"100%",height:"100%",padding:"20px"},children:[e.jsx("canvas",{ref:j,onClick:T,onMouseMove:z,onMouseLeave:W,onTouchStart:B,style:{maxWidth:"100%",maxHeight:"100%",objectFit:"contain",cursor:"crosshair",borderRadius:"8px",boxShadow:"0 4px 20px rgba(0, 0, 0, 0.1)",touchAction:"none"}}),v&&window.innerWidth>768&&e.jsxs("div",{style:{position:"fixed",left:C.x+20,top:C.y+20,pointerEvents:"none",zIndex:1e3},children:[e.jsx("div",{style:{width:"80px",height:"80px",borderRadius:"50%",backgroundColor:v,border:"3px solid white",boxShadow:"0 4px 12px rgba(0, 0, 0, 0.3)"}}),e.jsx("div",{style:{marginTop:"8px",padding:"6px 12px",background:"rgba(0, 0, 0, 0.8)",color:"white",borderRadius:"6px",fontSize:"12px",fontFamily:"monospace",fontWeight:600,textAlign:"center",whiteSpace:"nowrap"},children:v.toUpperCase()})]})]}):e.jsxs("label",{style:{display:"flex",flexDirection:"column",alignItems:"center",gap:"16px",padding:"40px",cursor:"pointer",textAlign:"center"},children:[e.jsx("div",{style:{width:"80px",height:"80px",borderRadius:"50%",background:"#F3F4F6",display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.2s ease"},onMouseEnter:t=>{t.currentTarget.style.background="#E5E7EB",t.currentTarget.style.transform="scale(1.05)"},onMouseLeave:t=>{t.currentTarget.style.background="#F3F4F6",t.currentTarget.style.transform="scale(1)"},children:e.jsx(O,{size:32,strokeWidth:2,color:"#6B7280"})}),e.jsxs("div",{children:[e.jsx("p",{style:{fontSize:"16px",fontWeight:600,color:"#1A1A1A",margin:"0 0 8px 0"},children:"Upload an image"}),e.jsx("p",{style:{fontSize:"14px",color:"#6B7280",margin:0},children:"Click to browse or drag and drop"}),e.jsx("p",{style:{fontSize:"12px",color:"#9CA3AF",margin:"8px 0 0 0"},children:"PNG, JPG, GIF up to 10MB"})]}),e.jsx("input",{ref:k,type:"file",accept:"image/*",onChange:R,style:{display:"none"}})]})})]})}),b&&e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"16px",overflowY:"auto",height:"100%"},children:[e.jsxs("div",{style:{background:"#FFFFFF",borderRadius:"14px",padding:"24px",border:"1px solid #E5E7EB",boxShadow:"0 1px 2px rgba(0, 0, 0, 0.04)"},children:[e.jsxs("div",{style:{width:"100%",height:"200px",borderRadius:"12px",backgroundColor:x,border:"1px solid #E5E7EB",boxShadow:"0 4px 20px rgba(0, 0, 0, 0.1)",position:"relative",overflow:"hidden"},children:[e.jsx("div",{style:{position:"absolute",inset:0,backgroundImage:"linear-gradient(45deg, #E5E5E5 25%, transparent 25%), linear-gradient(-45deg, #E5E5E5 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #E5E5E5 75%), linear-gradient(-45deg, transparent 75%, #E5E5E5 75%)",backgroundSize:"20px 20px",backgroundPosition:"0 0, 0 10px, 10px -10px, -10px 0px",backgroundColor:"#FAFAFA",zIndex:0}}),e.jsx("div",{style:{position:"absolute",inset:0,backgroundColor:x,zIndex:1}})]}),e.jsx("div",{style:{marginTop:"16px",padding:"16px",background:"#FAFAFA",borderRadius:"10px",border:"1px solid #E5E7EB"},children:e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"8px"},children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",fontSize:"14px"},children:[e.jsx("span",{style:{color:"#6B7280",fontWeight:500},children:"HEX"}),e.jsx("span",{style:{fontFamily:"monospace",fontWeight:600,color:"#1A1A1A"},children:x.toUpperCase()})]}),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",fontSize:"14px"},children:[e.jsx("span",{style:{color:"#6B7280",fontWeight:500},children:"RGB"}),e.jsxs("span",{style:{fontFamily:"monospace",fontWeight:600,color:"#1A1A1A"},children:[g.r,", ",g.g,", ",g.b]})]}),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",fontSize:"14px"},children:[e.jsx("span",{style:{color:"#6B7280",fontWeight:500},children:"HSL"}),e.jsxs("span",{style:{fontFamily:"monospace",fontWeight:600,color:"#1A1A1A"},children:[h.h,"°, ",h.s,"%, ",h.l,"%"]})]})]})})]}),e.jsx("div",{style:{background:"#FFFFFF",borderRadius:"14px",padding:"24px",border:"1px solid #E5E7EB",boxShadow:"0 1px 2px rgba(0, 0, 0, 0.04)",marginBottom:"24px"},children:e.jsx("div",{style:{display:"flex",flexDirection:"column",gap:"12px"},children:P.map(t=>e.jsxs("div",{children:[e.jsx("label",{style:{display:"block",fontSize:"12px",color:"#6B7280",marginBottom:"8px",fontWeight:500},children:t.label}),e.jsxs("div",{style:{display:"flex",gap:"8px"},children:[e.jsx("input",{type:"text",value:t.value,readOnly:!0,style:{flex:1,height:"44px",padding:"0 16px",border:"1px solid #E5E7EB",borderRadius:"10px",fontSize:"14px",fontFamily:"monospace",background:"#FAFAFA",color:"#1A1A1A",outline:"none"}}),e.jsx("button",{onClick:()=>D(t.value,t.label),style:{width:"44px",height:"44px",display:"flex",alignItems:"center",justifyContent:"center",background:y===t.label?"#10B981":"#1A1A1A",color:"#FFFFFF",border:"none",borderRadius:"10px",cursor:"pointer",transition:"all 0.2s ease",flexShrink:0},onMouseEnter:n=>{y!==t.label&&(n.currentTarget.style.background="#2A2A2A")},onMouseLeave:n=>{y!==t.label&&(n.currentTarget.style.background="#1A1A1A")},children:y===t.label?e.jsx(G,{size:18,strokeWidth:2.5}):e.jsx(Y,{size:18,strokeWidth:2})})]})]},t.label))})})]})]})]})]})}export{te as default};
