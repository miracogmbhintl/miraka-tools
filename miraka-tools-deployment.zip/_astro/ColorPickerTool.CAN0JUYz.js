import{j as e}from"./jsx-runtime.D_zvdyIk.js";import{r as m}from"./index.CRdpAhVf.js";import{Z as w}from"./index.B6xPKDnB.js";import{b as C}from"./base-url.DVjYrgnb.js";import{C as S,a as B}from"./copy.DYW1hB-b.js";import"./createLucideIcon.CB-2PyP6.js";function H(){const[s,h]=m.useState("#F37021"),[x,u]=m.useState(null),v=o=>/^#[0-9A-Fa-f]{6}$/.test(o),b=o=>{if(!v(o))return null;const t=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(o);return t?{r:parseInt(t[1],16),g:parseInt(t[2],16),b:parseInt(t[3],16)}:null},j=o=>{const t=b(o);if(!t)return null;const n=t.r/255,i=t.g/255,r=t.b/255,d=Math.max(n,i,r),p=Math.min(n,i,r);let g=0,f=0;const y=(d+p)/2;if(d!==p){const c=d-p;switch(f=y>.5?c/(2-d-p):c/(d+p),d){case n:g=((i-r)/c+(i<r?6:0))/6;break;case i:g=((r-n)/c+2)/6;break;case r:g=((n-i)/c+4)/6;break}}return{h:Math.round(g*360),s:Math.round(f*100),l:Math.round(y*100)}},k=(o,t,n)=>"#"+[o,t,n].map(i=>{const r=Math.max(0,Math.min(255,i)).toString(16);return r.length===1?"0"+r:r}).join(""),A=(o,t)=>{navigator.clipboard.writeText(o),u(t),setTimeout(()=>u(null),2e3)},l=b(s)||{r:0,g:0,b:0},a=j(s)||{h:0,s:0,l:0},F=(o,t)=>{const n=parseInt(t)||0,i=Math.max(0,Math.min(255,n)),r={...l,[o]:i};h(k(r.r,r.g,r.b))},E=[{label:"HEX",value:s.toUpperCase()},{label:"RGB",value:`rgb(${l.r}, ${l.g}, ${l.b})`},{label:"HSL",value:`hsl(${a.h}, ${a.s}%, ${a.l}%)`}];return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`
        .color-picker-container {
          font-family: Inter, sans-serif;
          position: relative;
          height: 100vh;
          width: 100vw;
          padding: 20px;
          box-sizing: border-box;
          overflow: hidden;
        }
        
        .color-picker-back-button {
          position: fixed;
          left: calc((40px + 24px) / 2);
          top: 50%;
          transform: translate(-50%, -50%);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          text-decoration: none;
          z-index: 1000;
          transition: all 0.2s ease;
        }
        
        .color-picker-logo {
          display: none;
        }
        
        .color-picker-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 24px;
          height: 100%;
          width: 100%;
          padding-left: 40px;
        }
        
        .color-picker-left-column {
          display: flex;
          flex-direction: column;
          gap: 16px;
          overflow-y: auto;
          overflow-x: hidden;
          padding-right: 16px;
          height: 100%;
        }
        
        .color-picker-right-column {
          position: sticky;
          top: 0;
          height: 100%;
          overflow: hidden;
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        
        @media (max-width: 768px) {
          .color-picker-container {
            padding: 12px;
            height: auto;
            min-height: 100vh;
            overflow-y: auto;
            display: flex;
            align-items: flex-start;
            justify-content: center;
          }
          
          .color-picker-back-button {
            position: fixed;
            left: 12px;
            top: 12px;
            transform: none;
          }
          
          .color-picker-logo {
            display: block;
            position: fixed;
            right: 12px;
            top: 12px;
            z-index: 1000;
            font-family: 'Montserrat', sans-serif;
            font-size: 16px;
            font-weight: 700;
            color: #1A1A1A;
          }
          
          .color-picker-grid {
            display: flex;
            flex-direction: column;
            gap: 16px;
            padding-left: 0;
            padding-top: 50px;
            height: auto;
            width: 90vw;
            max-width: 90vw;
          }
          
          .color-picker-left-column {
            padding-right: 0;
            height: auto;
            overflow: visible;
          }
          
          .color-picker-right-column {
            position: relative;
            height: auto;
            overflow: visible;
          }
        }
      `}),e.jsxs("div",{className:"color-picker-container",children:[e.jsx("a",{href:`${C}/`,className:"color-picker-back-button",onMouseEnter:o=>{const t=o.currentTarget.querySelector("svg");t&&t.setAttribute("stroke","#F37021")},onMouseLeave:o=>{const t=o.currentTarget.querySelector("svg");t&&t.setAttribute("stroke","#1A1A1A")},children:e.jsx("svg",{width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"#1A1A1A",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",children:e.jsx("path",{d:"M15 18l-6-6 6-6"})})}),e.jsx("div",{className:"color-picker-logo",children:e.jsx("img",{src:"https://cdn.prod.website-files.com/68dc2b9c31cb83ac9f84a1af/68e0480bc44f1d28032afb51_LOGO%20MIRAKA%20%26%20CO%20PLAIN%20TEXT.png",alt:"Miraka & Co.",style:{height:"18px",width:"auto",display:"block"}})}),e.jsxs("div",{className:"color-picker-grid",children:[e.jsxs("div",{className:"color-picker-left-column",children:[e.jsx("div",{style:{background:"#FFFFFF",borderRadius:"14px",padding:"24px",border:"1px solid #E5E7EB",boxShadow:"0 1px 2px rgba(0, 0, 0, 0.04)"},children:e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"16px"},children:[e.jsx("div",{style:{width:"100%",borderRadius:"12px",overflow:"hidden"},children:e.jsx(w,{color:s,onChange:h,style:{width:"100%",height:"200px"}})}),e.jsxs("div",{style:{display:"flex",gap:"8px",alignItems:"flex-end"},children:[e.jsxs("div",{style:{flex:"0 0 110px"},children:[e.jsx("label",{style:{display:"block",fontSize:"11px",color:"#6B7280",marginBottom:"4px",fontWeight:500},children:"HEX"}),e.jsx("input",{type:"text",value:s,onChange:o=>{const t=o.target.value;t.startsWith("#")&&h(t.toUpperCase())},maxLength:7,style:{width:"100%",height:"36px",padding:"0 10px",border:"1px solid #E5E7EB",borderRadius:"8px",fontSize:"13px",fontFamily:"monospace",outline:"none",transition:"all 0.2s ease"},onFocus:o=>{o.currentTarget.style.borderColor="#1A1A1A",o.currentTarget.style.boxShadow="0 0 0 3px rgba(26, 26, 26, 0.05)"},onBlur:o=>{o.currentTarget.style.borderColor="#E5E7EB",o.currentTarget.style.boxShadow="none"}})]}),["r","g","b"].map(o=>e.jsxs("div",{style:{flex:"1"},children:[e.jsx("label",{style:{display:"block",fontSize:"11px",color:"#6B7280",marginBottom:"4px",fontWeight:500},children:o.toUpperCase()}),e.jsx("input",{type:"number",min:"0",max:"255",value:l[o],onChange:t=>F(o,t.target.value),style:{width:"100%",height:"36px",padding:"0 8px",border:"1px solid #E5E7EB",borderRadius:"8px",fontSize:"13px",outline:"none",transition:"all 0.2s ease"},onFocus:t=>{t.currentTarget.style.borderColor="#1A1A1A",t.currentTarget.style.boxShadow="0 0 0 3px rgba(26, 26, 26, 0.05)"},onBlur:t=>{t.currentTarget.style.borderColor="#E5E7EB",t.currentTarget.style.boxShadow="none"}})]},o))]})]})}),e.jsx("div",{style:{background:"#FFFFFF",borderRadius:"14px",padding:"24px",border:"1px solid #E5E7EB",boxShadow:"0 1px 2px rgba(0, 0, 0, 0.04)"},children:e.jsx("div",{style:{display:"flex",flexDirection:"column",gap:"12px"},children:E.map(o=>e.jsxs("div",{children:[e.jsx("label",{style:{display:"block",fontSize:"12px",color:"#6B7280",marginBottom:"8px",fontWeight:500},children:o.label}),e.jsxs("div",{style:{display:"flex",gap:"8px"},children:[e.jsx("input",{type:"text",value:o.value,readOnly:!0,style:{flex:1,height:"44px",padding:"0 16px",border:"1px solid #E5E7EB",borderRadius:"10px",fontSize:"14px",fontFamily:"monospace",background:"#FAFAFA",color:"#1A1A1A",outline:"none"}}),e.jsx("button",{onClick:()=>A(o.value,o.label),style:{width:"44px",height:"44px",display:"flex",alignItems:"center",justifyContent:"center",background:x===o.label?"#10B981":"#1A1A1A",color:"#FFFFFF",border:"none",borderRadius:"10px",cursor:"pointer",transition:"all 0.2s ease",flexShrink:0},onMouseEnter:t=>{x!==o.label&&(t.currentTarget.style.background="#2A2A2A")},onMouseLeave:t=>{x!==o.label&&(t.currentTarget.style.background="#1A1A1A")},children:x===o.label?e.jsx(S,{size:18,strokeWidth:2.5}):e.jsx(B,{size:18,strokeWidth:2})})]})]},o.label))})})]}),e.jsxs("div",{className:"color-picker-right-column",children:[e.jsx("div",{style:{background:"#FFFFFF",borderRadius:"14px",padding:"24px",border:"1px solid #E5E7EB",boxShadow:"0 1px 2px rgba(0, 0, 0, 0.04)",flex:1,display:"flex",flexDirection:"column"},children:e.jsx("div",{style:{flex:1,position:"relative",display:"flex",alignItems:"center",justifyContent:"center",padding:"20px",borderRadius:"12px",backgroundImage:"linear-gradient(45deg, #E5E5E5 25%, transparent 25%), linear-gradient(-45deg, #E5E5E5 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #E5E5E5 75%), linear-gradient(-45deg, transparent 75%, #E5E5E5 75%)",backgroundSize:"20px 20px",backgroundPosition:"0 0, 0 10px, 10px -10px, -10px 0px",backgroundColor:"#FAFAFA",minHeight:0},children:e.jsx("div",{style:{backgroundColor:s,width:"100%",height:"100%",borderRadius:"12px",boxShadow:"0 4px 20px rgba(0, 0, 0, 0.1)"}})})}),e.jsx("div",{style:{background:"#FFFFFF",borderRadius:"14px",padding:"24px",border:"1px solid #E5E7EB",boxShadow:"0 1px 2px rgba(0, 0, 0, 0.04)"},children:e.jsx("div",{style:{padding:"16px",background:"#FAFAFA",borderRadius:"10px",border:"1px solid #E5E7EB"},children:e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"8px"},children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",fontSize:"14px"},children:[e.jsx("span",{style:{color:"#6B7280",fontWeight:500},children:"HEX"}),e.jsx("span",{style:{fontFamily:"monospace",fontWeight:600,color:"#1A1A1A"},children:s.toUpperCase()})]}),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",fontSize:"14px"},children:[e.jsx("span",{style:{color:"#6B7280",fontWeight:500},children:"RGB"}),e.jsxs("span",{style:{fontFamily:"monospace",fontWeight:600,color:"#1A1A1A"},children:[l.r,", ",l.g,", ",l.b]})]}),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",fontSize:"14px"},children:[e.jsx("span",{style:{color:"#6B7280",fontWeight:500},children:"HSL"}),e.jsxs("span",{style:{fontFamily:"monospace",fontWeight:600,color:"#1A1A1A"},children:[a.h,"°, ",a.s,"%, ",a.l,"%"]})]})]})})})]})]})]})]})}export{H as default};
