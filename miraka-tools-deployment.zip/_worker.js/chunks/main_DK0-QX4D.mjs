globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, f as createAstro, h as addAttribute, o as renderHead, p as renderSlot, r as renderTemplate } from './astro/server_CnmPaQ2a.mjs';
/* empty css                            */

const $$Astro = createAstro();
const $$Main = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Main;
  const { pageClass = "" } = Astro2.props;
  return renderTemplate`<html lang="en"${addAttribute(pageClass, "class")}> <head><meta charset="utf-8"><link rel="icon" type="image/png" href="/favicon.ico"><meta name="viewport" content="width=device-width"><meta name="generator"${addAttribute(Astro2.generator, "content")}><title>Miraka & Co. Tools</title>${renderHead()}</head> <!-- Dark mode class injection point - will be replaced with \`dark\` class based on your site palette --> <body class="__DARK_MODE_CLASS__"> ${renderSlot($$result, $$slots["default"])} </body></html>`;
}, "/app/src/layouts/main.astro", void 0);

export { $$Main as $ };
