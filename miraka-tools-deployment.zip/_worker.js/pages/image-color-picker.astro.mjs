globalThis.process ??= {}; globalThis.process.env ??= {};
import { e as createComponent, k as renderComponent, r as renderTemplate } from '../chunks/astro/server_CnmPaQ2a.mjs';
import { $ as $$Main } from '../chunks/main_DK0-QX4D.mjs';
export { renderers } from '../renderers.mjs';

const $$ImageColorPicker = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "MainLayout", $$Main, {}, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "ImageColorPickerTool", null, { "client:only": "react", "client:component-hydration": "only", "client:component-path": "/app/src/components/ImageColorPickerTool", "client:component-export": "default" })} ` })}`;
}, "/app/src/pages/image-color-picker.astro", void 0);

const $$file = "/app/src/pages/image-color-picker.astro";
const $$url = "/image-color-picker";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$ImageColorPicker,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
