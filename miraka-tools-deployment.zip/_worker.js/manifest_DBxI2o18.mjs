globalThis.process ??= {}; globalThis.process.env ??= {};
import { q as decodeKey } from './chunks/astro/server_CnmPaQ2a.mjs';
import './chunks/astro-designed-error-pages_0K9tsQGc.mjs';
import { N as NOOP_MIDDLEWARE_FN } from './chunks/noop-middleware_hnvbRnn3.mjs';

function sanitizeParams(params) {
  return Object.fromEntries(
    Object.entries(params).map(([key, value]) => {
      if (typeof value === "string") {
        return [key, value.normalize().replace(/#/g, "%23").replace(/\?/g, "%3F")];
      }
      return [key, value];
    })
  );
}
function getParameter(part, params) {
  if (part.spread) {
    return params[part.content.slice(3)] || "";
  }
  if (part.dynamic) {
    if (!params[part.content]) {
      throw new TypeError(`Missing parameter: ${part.content}`);
    }
    return params[part.content];
  }
  return part.content.normalize().replace(/\?/g, "%3F").replace(/#/g, "%23").replace(/%5B/g, "[").replace(/%5D/g, "]");
}
function getSegment(segment, params) {
  const segmentPath = segment.map((part) => getParameter(part, params)).join("");
  return segmentPath ? "/" + segmentPath : "";
}
function getRouteGenerator(segments, addTrailingSlash) {
  return (params) => {
    const sanitizedParams = sanitizeParams(params);
    let trailing = "";
    if (addTrailingSlash === "always" && segments.length) {
      trailing = "/";
    }
    const path = segments.map((segment) => getSegment(segment, sanitizedParams)).join("") + trailing;
    return path || "/";
  };
}

function deserializeRouteData(rawRouteData) {
  return {
    route: rawRouteData.route,
    type: rawRouteData.type,
    pattern: new RegExp(rawRouteData.pattern),
    params: rawRouteData.params,
    component: rawRouteData.component,
    generate: getRouteGenerator(rawRouteData.segments, rawRouteData._meta.trailingSlash),
    pathname: rawRouteData.pathname || void 0,
    segments: rawRouteData.segments,
    prerender: rawRouteData.prerender,
    redirect: rawRouteData.redirect,
    redirectRoute: rawRouteData.redirectRoute ? deserializeRouteData(rawRouteData.redirectRoute) : void 0,
    fallbackRoutes: rawRouteData.fallbackRoutes.map((fallback) => {
      return deserializeRouteData(fallback);
    }),
    isIndex: rawRouteData.isIndex,
    origin: rawRouteData.origin
  };
}

function deserializeManifest(serializedManifest) {
  const routes = [];
  for (const serializedRoute of serializedManifest.routes) {
    routes.push({
      ...serializedRoute,
      routeData: deserializeRouteData(serializedRoute.routeData)
    });
    const route = serializedRoute;
    route.routeData = deserializeRouteData(serializedRoute.routeData);
  }
  const assets = new Set(serializedManifest.assets);
  const componentMetadata = new Map(serializedManifest.componentMetadata);
  const inlinedScripts = new Map(serializedManifest.inlinedScripts);
  const clientDirectives = new Map(serializedManifest.clientDirectives);
  const serverIslandNameMap = new Map(serializedManifest.serverIslandNameMap);
  const key = decodeKey(serializedManifest.key);
  return {
    // in case user middleware exists, this no-op middleware will be reassigned (see plugin-ssr.ts)
    middleware() {
      return { onRequest: NOOP_MIDDLEWARE_FN };
    },
    ...serializedManifest,
    assets,
    componentMetadata,
    inlinedScripts,
    clientDirectives,
    routes,
    serverIslandNameMap,
    key
  };
}

const manifest = deserializeManifest({"hrefRoot":"file:///app/","cacheDir":"file:///app/node_modules/.astro/","outDir":"file:///app/dist/","srcDir":"file:///app/src/","publicDir":"file:///app/public/","buildClientDir":"file:///app/dist/","buildServerDir":"file:///app/dist/_worker.js/","adapterName":"@astrojs/cloudflare","routes":[{"file":"","links":[],"scripts":[],"styles":[],"routeData":{"type":"page","component":"_server-islands.astro","params":["name"],"segments":[[{"content":"_server-islands","dynamic":false,"spread":false}],[{"content":"name","dynamic":true,"spread":false}]],"pattern":"^\\/_server-islands\\/([^/]+?)\\/?$","prerender":false,"isIndex":false,"fallbackRoutes":[],"route":"/_server-islands/[name]","origin":"internal","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[],"routeData":{"type":"endpoint","isIndex":false,"route":"/_image","pattern":"^\\/_image\\/?$","segments":[[{"content":"_image","dynamic":false,"spread":false}]],"params":[],"component":"node_modules/@astrojs/cloudflare/dist/entrypoints/image-endpoint.js","pathname":"/_image","prerender":false,"fallbackRoutes":[],"origin":"internal","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[{"type":"external","src":"/_astro/analysis.D-RfpFsx.css"}],"routeData":{"route":"/404","isIndex":false,"type":"page","pattern":"^\\/404\\/?$","segments":[[{"content":"404","dynamic":false,"spread":false}]],"params":[],"component":"src/pages/404.astro","pathname":"/404","prerender":false,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[{"type":"external","src":"/_astro/analysis.D-RfpFsx.css"},{"type":"external","src":"/_astro/analysis.0sdEBl4c.css"}],"routeData":{"route":"/analysis","isIndex":false,"type":"page","pattern":"^\\/analysis\\/?$","segments":[[{"content":"analysis","dynamic":false,"spread":false}]],"params":[],"component":"src/pages/analysis.astro","pathname":"/analysis","prerender":false,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[],"routeData":{"route":"/api/analyze-website","isIndex":false,"type":"endpoint","pattern":"^\\/api\\/analyze-website\\/?$","segments":[[{"content":"api","dynamic":false,"spread":false}],[{"content":"analyze-website","dynamic":false,"spread":false}]],"params":[],"component":"src/pages/api/analyze-website.ts","pathname":"/api/analyze-website","prerender":false,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[{"type":"external","src":"/_astro/analysis.D-RfpFsx.css"}],"routeData":{"route":"/color-picker","isIndex":false,"type":"page","pattern":"^\\/color-picker\\/?$","segments":[[{"content":"color-picker","dynamic":false,"spread":false}]],"params":[],"component":"src/pages/color-picker.astro","pathname":"/color-picker","prerender":false,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[{"type":"inline","content":"body{margin:0;padding:0;overflow:hidden}@media (max-width: 768px){body{overflow:auto}}\n"},{"type":"external","src":"/_astro/HTMLPreviewTool.D93C6ejO.css"}],"routeData":{"route":"/html","isIndex":false,"type":"page","pattern":"^\\/html\\/?$","segments":[[{"content":"html","dynamic":false,"spread":false}]],"params":[],"component":"src/pages/html.astro","pathname":"/html","prerender":false,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[{"type":"external","src":"/_astro/analysis.D-RfpFsx.css"}],"routeData":{"route":"/image-color-picker","isIndex":false,"type":"page","pattern":"^\\/image-color-picker\\/?$","segments":[[{"content":"image-color-picker","dynamic":false,"spread":false}]],"params":[],"component":"src/pages/image-color-picker.astro","pathname":"/image-color-picker","prerender":false,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[{"type":"external","src":"/_astro/analysis.D-RfpFsx.css"}],"routeData":{"route":"/qr","isIndex":false,"type":"page","pattern":"^\\/qr\\/?$","segments":[[{"content":"qr","dynamic":false,"spread":false}]],"params":[],"component":"src/pages/qr.astro","pathname":"/qr","prerender":false,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[{"type":"external","src":"/_astro/analysis.D-RfpFsx.css"},{"type":"external","src":"/_astro/HTMLPreviewTool.D93C6ejO.css"}],"routeData":{"route":"/tools","isIndex":false,"type":"page","pattern":"^\\/tools\\/?$","segments":[[{"content":"tools","dynamic":false,"spread":false}]],"params":[],"component":"src/pages/tools.astro","pathname":"/tools","prerender":false,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[{"type":"external","src":"/_astro/analysis.D-RfpFsx.css"}],"routeData":{"route":"/","isIndex":true,"type":"page","pattern":"^\\/$","segments":[],"params":[],"component":"src/pages/index.astro","pathname":"/","prerender":false,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}}],"base":"/","trailingSlash":"ignore","compressHTML":true,"componentMetadata":[["/app/src/pages/html.astro",{"propagation":"none","containsHead":true}],["/app/src/pages/404.astro",{"propagation":"none","containsHead":true}],["/app/src/pages/analysis.astro",{"propagation":"none","containsHead":true}],["/app/src/pages/color-picker.astro",{"propagation":"none","containsHead":true}],["/app/src/pages/image-color-picker.astro",{"propagation":"none","containsHead":true}],["/app/src/pages/index.astro",{"propagation":"none","containsHead":true}],["/app/src/pages/qr.astro",{"propagation":"none","containsHead":true}],["/app/src/pages/tools.astro",{"propagation":"none","containsHead":true}]],"renderers":[],"clientDirectives":[["idle","(()=>{var l=(n,t)=>{let i=async()=>{await(await n())()},e=typeof t.value==\"object\"?t.value:void 0,s={timeout:e==null?void 0:e.timeout};\"requestIdleCallback\"in window?window.requestIdleCallback(i,s):setTimeout(i,s.timeout||200)};(self.Astro||(self.Astro={})).idle=l;window.dispatchEvent(new Event(\"astro:idle\"));})();"],["load","(()=>{var e=async t=>{await(await t())()};(self.Astro||(self.Astro={})).load=e;window.dispatchEvent(new Event(\"astro:load\"));})();"],["media","(()=>{var n=(a,t)=>{let i=async()=>{await(await a())()};if(t.value){let e=matchMedia(t.value);e.matches?i():e.addEventListener(\"change\",i,{once:!0})}};(self.Astro||(self.Astro={})).media=n;window.dispatchEvent(new Event(\"astro:media\"));})();"],["only","(()=>{var e=async t=>{await(await t())()};(self.Astro||(self.Astro={})).only=e;window.dispatchEvent(new Event(\"astro:only\"));})();"],["visible","(()=>{var a=(s,i,o)=>{let r=async()=>{await(await s())()},t=typeof i.value==\"object\"?i.value:void 0,c={rootMargin:t==null?void 0:t.rootMargin},n=new IntersectionObserver(e=>{for(let l of e)if(l.isIntersecting){n.disconnect(),r();break}},c);for(let e of o.children)n.observe(e)};(self.Astro||(self.Astro={})).visible=a;window.dispatchEvent(new Event(\"astro:visible\"));})();"]],"entryModules":{"\u0000astro-internal:middleware":"_astro-internal_middleware.mjs","\u0000noop-actions":"_noop-actions.mjs","\u0000@astro-page:src/pages/404@_@astro":"pages/404.astro.mjs","\u0000@astro-page:src/pages/analysis@_@astro":"pages/analysis.astro.mjs","\u0000@astro-page:src/pages/api/analyze-website@_@ts":"pages/api/analyze-website.astro.mjs","\u0000@astro-page:src/pages/color-picker@_@astro":"pages/color-picker.astro.mjs","\u0000@astro-page:src/pages/html@_@astro":"pages/html.astro.mjs","\u0000@astro-page:src/pages/image-color-picker@_@astro":"pages/image-color-picker.astro.mjs","\u0000@astro-page:src/pages/qr@_@astro":"pages/qr.astro.mjs","\u0000@astro-page:src/pages/tools@_@astro":"pages/tools.astro.mjs","\u0000@astro-page:src/pages/index@_@astro":"pages/index.astro.mjs","\u0000@astrojs-ssr-virtual-entry":"index.js","\u0000@astro-renderers":"renderers.mjs","\u0000@astro-page:node_modules/@astrojs/cloudflare/dist/entrypoints/image-endpoint@_@js":"pages/_image.astro.mjs","\u0000@astrojs-ssr-adapter":"_@astrojs-ssr-adapter.mjs","\u0000@astrojs-manifest":"manifest_DBxI2o18.mjs","/app/node_modules/unstorage/drivers/cloudflare-kv-binding.mjs":"chunks/cloudflare-kv-binding_DMly_2Gl.mjs","/app/node_modules/astro/dist/assets/services/sharp.js":"chunks/sharp_WSL8a24v.mjs","/app/src/components/ToolsShell":"_astro/ToolsShell._nzFRgmE.js","/app/src/components/ToolsPage":"_astro/ToolsPage.WpU_M9Wd.js","/app/src/components/NotFoundWrapper":"_astro/NotFoundWrapper.BZfA4Pin.js","/app/src/components/ImageColorPickerTool":"_astro/ImageColorPickerTool.BQVuECCT.js","/app/src/components/HomePageWithLoader":"_astro/HomePageWithLoader.BlXkUmW9.js","/app/src/components/WebsiteIntelligenceTool":"_astro/WebsiteIntelligenceTool.DREIwpB-.js","@astrojs/react/client.js":"_astro/client.P6Of3eS8.js","/app/src/components/ColorPickerTool":"_astro/ColorPickerTool.CAN0JUYz.js","/app/src/components/HTMLPreviewTool":"_astro/HTMLPreviewTool.B6xtZ5EQ.js","/app/src/components/QRCodeTool":"_astro/QRCodeTool.Dui5QYAB.js","astro:scripts/before-hydration.js":""},"inlinedScripts":[],"assets":["/_astro/analysis.D-RfpFsx.css","/favicon.ico","/_worker.js/_@astrojs-ssr-adapter.mjs","/_worker.js/_astro-internal_middleware.mjs","/_worker.js/_noop-actions.mjs","/_worker.js/index.js","/_worker.js/renderers.mjs","/_astro/BackgroundVideo.CV74Xbqa.js","/_astro/ColorPickerTool.CAN0JUYz.js","/_astro/HTMLPreviewTool.B6xtZ5EQ.js","/_astro/HTMLPreviewTool.D93C6ejO.css","/_astro/HomePageWithLoader.BlXkUmW9.js","/_astro/ImageColorPickerTool.BQVuECCT.js","/_astro/NotFoundWrapper.BZfA4Pin.js","/_astro/QRCodeTool.Dui5QYAB.js","/_astro/ToolsPage.WpU_M9Wd.js","/_astro/ToolsShell._nzFRgmE.js","/_astro/WebsiteIntelligenceTool.DREIwpB-.js","/_astro/analysis.0sdEBl4c.css","/_astro/base-url.DVjYrgnb.js","/_astro/client.P6Of3eS8.js","/_astro/copy.DYW1hB-b.js","/_astro/createLucideIcon.CB-2PyP6.js","/_astro/download.CtBmHxYT.js","/_astro/index.B6xPKDnB.js","/_astro/index.CRdpAhVf.js","/_astro/jsx-runtime.D_zvdyIk.js","/_worker.js/_astro/analysis.D-RfpFsx.css","/_worker.js/pages/404.astro.mjs","/_worker.js/pages/_image.astro.mjs","/_worker.js/pages/analysis.astro.mjs","/_worker.js/pages/color-picker.astro.mjs","/_worker.js/pages/html.astro.mjs","/_worker.js/pages/image-color-picker.astro.mjs","/_worker.js/pages/index.astro.mjs","/_worker.js/pages/qr.astro.mjs","/_worker.js/pages/tools.astro.mjs","/_worker.js/chunks/_@astrojs-ssr-adapter_D4sEqKWK.mjs","/_worker.js/chunks/astro-designed-error-pages_0K9tsQGc.mjs","/_worker.js/chunks/astro_C7QrAbXV.mjs","/_worker.js/chunks/cloudflare-kv-binding_DMly_2Gl.mjs","/_worker.js/chunks/image-endpoint_CnSprfUA.mjs","/_worker.js/chunks/index_BM7rIcsP.mjs","/_worker.js/chunks/main_DK0-QX4D.mjs","/_worker.js/chunks/noop-middleware_hnvbRnn3.mjs","/_worker.js/chunks/path_lFLZ0pUM.mjs","/_worker.js/chunks/sharp_WSL8a24v.mjs","/_worker.js/pages/api/analyze-website.astro.mjs","/_worker.js/chunks/astro/server_CnmPaQ2a.mjs"],"buildFormat":"directory","checkOrigin":true,"serverIslandNameMap":[],"key":"9wpxJYdSRa7xRdgjuOYlErB2oQECkQZDUAJTPAd1MPI=","sessionConfig":{"driver":"cloudflare-kv-binding","options":{"binding":"SESSION"}}});
if (manifest.sessionConfig) manifest.sessionConfig.driverModule = () => import('./chunks/cloudflare-kv-binding_DMly_2Gl.mjs');

export { manifest };
